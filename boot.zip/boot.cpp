#include <iostream>
#include <string>
#include <unordered_map>
using namespace std;

// Function to analyze user input and respond
string getResponse(const string &userInput) {
    // Predefined responses
    unordered_map<string, string> responses = {
        {"hello", "Hello! How can I assist you today?"},
        {"how are you", "I'm just a bot, but I'm here to help you!"},
        {"what is your name", "I am your AI Chatbot!"},
        {"bye", "Goodbye! Have a great day!"},
        {"help", "Sure! You can ask me anything about programming, tasks, or general queries."}
    };

    // Convert input to lowercase for case-insensitive matching
    string input = userInput;
    for (char &c : input) {
        c = tolower(c);
    }

    // Search for a response
    if (responses.find(input) != responses.end()) {
        return responses[input];
    } else {
        return "I'm sorry, I don't understand that. Can you rephrase?";
    }
}

int main() {
    string userInput;
    cout << "Welcome to the AI Chatbot! Type 'bye' to exit." << endl;

    do {
        cout << "\nYou: ";
        getline(cin, userInput);

        // Get chatbot's response
        string response = getResponse(userInput);
        cout << "Bot: " << response;

        // Exit loop if user says 'bye'
        if (userInput == "bye" || userInput == "Bye") {
            break;
        }

    } while (true);

    cout << "\nChatbot session ended." << endl;
    return 0;
}